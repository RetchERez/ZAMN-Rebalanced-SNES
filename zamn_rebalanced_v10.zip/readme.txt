ZOMBIES ATE MY NEIGHBORS: REBALANCED v1.0
By Retch
SNES / USA / IPS Patch

============================================================
SUPPORTED ROM
============================================================

Game:        Zombies Ate My Neighbors (USA)
System:      Super Nintendo / SNES
ROM format:  Headerless, no 512-byte copier header
ROM size:    1,048,576 bytes

Clean ROM hashes:
CRC32:       7CFC0C7C
MD5:         23c2af7897d9384c4791189b68c142eb
SHA1:        9b6c31a32d58be12fa9975a247715bc52ecf1e1d
SHA256:      b27e2e957fa760f4f483e2af30e03062034a6c0066984f2e284cc2cb430b2059

Apply this patch only to that exact clean headerless USA ROM.
Do not add or remove a copier header before patching.

============================================================
PATCH FILE
============================================================

Patch:       zamn_rebalanced_v10.ips
Patch type:  IPS
Version:     v1.0
Author:      Retch

IPS hashes:
Size:        1,077 bytes
CRC32:       22DB761A
MD5:         e2f0788e33561f53441f5051aed86817
SHA1:        107da699be197eac76c986a3339084721c16a75a
SHA256:      19ce981c12736a8a7ad1d5f7f0b3f6cff017ee16c41cf3714e2e274dc43344dd

Expected patched ROM hashes:
Size:        1,048,576 bytes
CRC32:       0C534B1C
MD5:         4fdfa08772db0b7fb5f874d4ed49f9c4
SHA1:        b3e5f4dfc9b8b9841be5aea1301820b4bc1ebd90
SHA256:      c72f9a49996f7f08f0b4be704a9525fce0f21e4a436415235624b7071bab941b
SNES checksum complement: C778
SNES checksum:            3887

============================================================
INSTALLATION
============================================================

- Start with the clean headerless Zombies Ate My Neighbors (USA) ROM
- Apply zamn_rebalanced_v10.ips with Floating IPS, Lunar IPS, or another IPS patcher
- Load the patched ROM in an SNES emulator, flash cart, or compatible setup

No ROM file is included with this patch.

============================================================
FEATURES LIST
============================================================

* Full-campaign rebalance while preserving the original game structure
* Continuous normal-stage progression restores the roster to 10 victims
* Original four-character password system is left vanilla
* Squirt Gun is finite, not infinite
* Automatic fallback to Squirt Gun when a specialist weapon runs out, if Squirt ammo remains
* Player 1 and Player 2 fallback handling both supported
* Larger post-hit recovery windows to reduce damage chaining
* Giant Baby stomp and Jelly-style queued damage honor recovery timing
* Reverse weapon and item cycling: hold L while cycling
* Radar moved to R / Select
* Conservative specialist ammo economy buffs
* Bazooka pickups increased from 5 to 6 shells
* Major enemy HP outliers reduced
* Major boss HP outliers reduced
* Chainsaw Maniac movement reduced
* Regular spider, Giant Baby, and Evil Doll projectile/movement outliers reduced
* Stage-specific timed-tourist relief
* Level 28 timed-tourist placement repaired
* Level 36 final Cheerleader stale-state repair
* Level 38 pool-lounger victim gets a targeted spawn-delay safety fix
* Level 48 final captive can no longer be killed through the boss barrier
* Level 1 zombie pressure increased to keep the tutorial active
* Victim-adjacent respawn sources slowed where needed
* No broad enemy deletion pass
* No SRAM saving added
* No new password format added

============================================================
DETAILED FEATURES
============================================================

------------------------------------------------------------
1 - Victim and progression rules
------------------------------------------------------------

Normal continuous play no longer permanently punishes the player for losing
victims in earlier stages. When the game advances to the next normal stage, the
roster is restored to 10 victims.

The current-stage rule remains close to stock behavior:

* If at least one victim was rescued, losing the remaining victims can still
  complete the stage.
* If every victim is lost before any rescue, Game Over still happens

The original four-character password system is intentionally unchanged. Old
passwords, reduced-victim variants, and generated passwords behave like vanilla.
This keeps password compatibility and avoids a fake inventory-saving system that
the original password interface cannot realistically support.

------------------------------------------------------------
2 - Ammo and resource economy
------------------------------------------------------------

The Squirt Gun remains finite. New games start with the original 150 Squirt
shots. Squirt pickups remain 99.

Final pickup amounts:

Squirt Gun:          99 pickup / 150 starting stock
Fire Extinguisher:   99
Bubble Gun:          45
Weed Whacker:       300
Ancient Artifact:    35
Bazooka:              6
Soda:                22
Tomato:              22
Popsicle:            22
Plate:               22
Silverware:          22
Football:            20
Flamethrower:       400
First Aid:            1

Only four fixed item type substitutions are made:

Level 16: Squirt Gun pickup -> Bubble Gun
Level 27: Squirt Gun pickup -> Silverware
Level 32: one Mystery Potion -> Bubble Gun
Level 34: one Decoy Clown -> Fire Extinguisher

The final 45-48 block contains enough deterministic resources for a fresh
password-style run, including 78 fixed Bazooka shells, 110 Soda, 35 Ancient
Artifact ammo, 99 Fire Extinguisher ammo, 22 Silverware, 99 additional Squirt
shots, and 4 fixed First Aid pickups.

------------------------------------------------------------
3 - Weapon fallback behavior
------------------------------------------------------------

When a finite specialist weapon fires its last shot, the game automatically
returns that player to the Squirt Gun only if that player still has Squirt ammo.

If Squirt ammo is also empty, the game does not select an unusable empty Squirt
slot. The player can cycle normally to another stocked weapon.

This behavior is implemented for both Player 1 and Player 2.

------------------------------------------------------------
4 - Player damage recovery
------------------------------------------------------------

Damage chaining is reduced without removing danger.

Recovery changes:

Ordinary post-hit recovery:        64 -> 128 frames
Floor/environment damage recovery: 32 -> 96 frames
Alternate recovery path:           48 -> 96 frames

Giant Baby stomp damage and queued/Jelly-style damage are routed through the
recovery timer so they cannot bypass the improved invulnerability window.

------------------------------------------------------------
5 - Controls and quality of life
------------------------------------------------------------

Reverse weapon and item cycling is built in.

Hold L while cycling to cycle backward.

Radar remains available on R / Select.

This keeps the original inventory system but makes weapon and item management
less clumsy during late-game resource pressure.

------------------------------------------------------------
6 - Enemy durability changes
------------------------------------------------------------

Only major durability outliers are reduced. The patch does not apply a global
damage multiplier.

Enemy HP changes:

Chainsaw Maniac:       151 -> 75
Werewolf:               10 -> 7
Durable Mummy variant:   4 -> 3
Evil Doll:               3 -> 2
Fire Baby:               8 -> 5
Item-carrying ant:       9 -> 7
Tough/red ant:          19 -> 11
Fishman/Squidman:        3 -> 2
Giant Baby:             70 -> 38
Snakeoid:               75 -> 56

Chainsaw Maniacs remain dangerous, but no longer take absurd amounts of basic
weapon damage. Snakeoids and red ants remain major threats, but are less
excessively spongey.

------------------------------------------------------------
7 - Boss changes
------------------------------------------------------------

Boss changes are targeted to long or unfair fights.

Giant Spider phase health:
20 -> 13
20 -> 13
45 -> 30

Level 36 Giant Spider modifier:
10 -> 7

Dr. Tongue giant-head phases:
35 -> 18
35 -> 18

Level 12 UFO hidden counter:
9 -> 7

UFO hatch/vulnerable windows are lengthened.

The Level 48 final boss remains the intended finale. The patch does not remove
the fight or bypass requirement.

------------------------------------------------------------
8 - Movement, projectile, and contact fairness
------------------------------------------------------------

Chainsaw Maniac movement is reduced by roughly 15%.

Regular spider movement components using 3-pixel steps are reduced to 2-pixel
steps.

Giant Baby's fastest chase/burst movement loses the extra final double-speed
step.

Evil Doll axes are reduced from 4 px/frame to 2 px/frame.

Selected oversized boss contact bounds are reduced so damage better matches
visible spacing.

------------------------------------------------------------
9 - Timed tourists
------------------------------------------------------------

The old global tourist-timer extension was removed. Final v1.0 uses
stage-specific timer relief.

Timed-tourist values:

Levels 7, 17, 36: extended value $A0
Levels 28, 42:    extended value $C0
Level 48:         moderate value $80
Other stages:     vanilla $40

These are engine constants, not exact real-time seconds.

------------------------------------------------------------
10 - Stage-specific fixes
------------------------------------------------------------

Level 8:
One victim is moved away from the initial Giant Baby danger area using an
existing legal pickup coordinate. The pickup is moved to the victim's former
legal coordinate.

Level 28:
The effectively impossible timed-tourist placement is repaired by swapping that
victim with an existing legal normal-victim position. This removes dependence on
sprite-limit abuse or exploit routing.

Level 36:
The final Cheerleader after the Giant Spider encounter receives a targeted
stale-state repair. The fix only clears a stale captive state when the related
thread is no longer live.

Level 38:
One Gillman/Fishman source near the pool-lounger victim has its cooldown changed
from 10 to 15. This is a targeted safety fix, not a broad density reduction.

Level 48:
The final captive Cheerleader at stock coordinates (90,70) cannot be killed
through the boss barrier. Other Level 48 victims remain normally vulnerable.
The intended two-phase boss and rescue flow remains required.

------------------------------------------------------------
11 - Enemy density and spawn fairness
------------------------------------------------------------

The patch avoids deleting enemies or rewriting entire stage layouts.

Level 1 keeps all 14 vanilla zombie sources. Nine slower sources receive shorter
cooldowns, making the tutorial more active while retaining safe victim spacing.
Final Level 1 aggregate spawn pressure is about 108% of vanilla.

Elsewhere, only true victim-adjacent respawn sources are slowed:

Under 32 px from victim: +20% cooldown
32-47 px from victim:    +15% cooldown
48+ px from victim:      vanilla, except one documented Level 38 outlier

The full campaign keeps respawning-stage density close to vanilla overall.

------------------------------------------------------------
12 - What is intentionally not changed
------------------------------------------------------------

- Does not add SRAM saving
- Does not add a new password format
- Does not make Squirt ammo infinite
- Does not remove ant item theft
- Does not delete broad enemy groups
- Does not globally reduce difficulty
- Does not redesign the game into a different campaign

============================================================
CREDITS
============================================================

Zombies Ate My Neighbors: Rebalanced v1.0
By Retch

Patch format: IPS
